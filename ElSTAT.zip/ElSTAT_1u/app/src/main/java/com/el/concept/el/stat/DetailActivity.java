package com.el.concept.el.stat;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.view.View;
import java.util.Locale;
 
public class DetailActivity extends Activity 
{
	String mString;
	WebView mWebView;
	ImageButton btnRetDet;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
		
		// On recupere la vue ...
		mWebView = (WebView)findViewById(R.id.webViewDetail);
		mWebView.getSettings().setJavaScriptEnabled(true);
		
		// Si le systeme est en francais, on charge le fichier html en francais 
		if(Locale.getDefault().getLanguage().equals("fr"))
			mWebView.loadUrl("file:///android_asset/html/presentation_fr.html");
		// ... sinon, on utilise celui en anglais
		else
			mWebView.loadUrl("file:///android_asset/html/presentation.html");
		
		btnRetDet = (ImageButton)findViewById(R.id.btnRetDet);
		btnRetDet.setOnClickListener(new View.OnClickListener ()
		{
			@Override
			public void onClick(View v)
			{
				finish();
			}
		});
		
    }
}
