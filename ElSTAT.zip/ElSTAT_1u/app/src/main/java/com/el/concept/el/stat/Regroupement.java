package com.el.concept.el.stat;

public class Regroupement 
{
	// Attributs
	private Classe classe; 
	private int m_fi; // Frequence absolue
	private double m_fiSurN; // Frequence absolue sur N
	private double m_fiSurNFois100; // Frequence absolue en pourcentage
	private int m_fcc; // Fonds cumules croissants
	private int m_fcd; // Fonds cumules decroissants
	private double m_mi; // Centre de classe
	private double m_fimi; // Frequence absolue multiplie par centre de classe
	
	// Attributs statiques
	private static int m_statFI = 0; // Sommation fi
	private static int m_statFCC = 0; // Variable statique des fonds cumules croissants
	private static int m_statFCD = 0; // Variable statique des fonds cumules decroissants
	private static int cptr = 0; // Variable d'aide ...
	private static double m_statFIMI = 0; // Sommation des fimi !
	
	// Constructeur 
	public Regroupement(double li, double ls, int fi, int n)
	{
		classe = new Classe (li, ls); // Instanciation de l'objet membre classe pour la limite inferieure et superieure 
		m_statFI = n; // Le total des frequences absolues correspond a "n"
		m_fi = fi;
		m_fiSurN = (double)fi / n;
		m_fiSurNFois100 = m_fiSurN * 100;
		m_statFCC += m_fi; // A chaque fois, on rajoute la frequence absolue presente 
		m_fcc = m_statFCC; // Fonds cumules actuels ...
		
		// Pour le fonds cumules decroissants ...
		if (cptr < 1)
		{
			m_statFCD = m_fcd = n;
			m_statFCD -= m_fi;
			cptr++;
		}	
		
		// ... 
		else
		{
			m_fcd = m_statFCD;
			m_statFCD -= m_fi;
		}
	
		m_mi = (li+ls)/2;
		m_fimi = m_fi*m_mi;
		m_statFIMI += m_fimi;
	}
	
	// Renvoie la sommation des "fimi"
	public static double totalFimi ()
	{
		return m_statFIMI;
	}
	
		// ACCESSEURS ...........
		
	// Renvoie la limite inferieur 
	public double getLi ()
	{
		return classe.getLi();
	}
	
	// Renvoie la frequence absolue
	public int getFi ()
	{
		return m_fi;
	}
		
	// Renvoie le fonds cumules croissants d'une classe 
	public int getFcc ()
	{
		return m_fcc;
	}
	
	// Renvoie le FIMI d'une classe 
	public double getFimi ()
	{
		return m_fimi;
	}
	
	/*
	 * renvoie la ligne qui sera afficher comme TOTAL dans notre tableau de regroupement
	*/
	public static String total()
	{
		return "<tfoot><tr><th>TOTAL</th><th>" 
			+ m_statFI 
			+ "</th><th>1</th><th>100</th><th>///</th><th>///</th><th>///</th><th>" 
			+ Stat.tronquer(m_statFIMI, 2) + "</th></tr></tfoot>";
	} 
	
	/*
	 * Renvoie pour chaque ligne de notre regroupement en tableau, toutes les donnees ...
	*/
	public String affichage ()
	{
		return classe.affichage ()
			+ "<td>" + m_fi + "</td>"
			+ "<td>" + Stat.tronquer(m_fiSurN, 2) + "</td>"
			+ "<td>" + Stat.tronquer(m_fiSurNFois100, 2) + "</td>"
			+ "<td>" + m_fcc + "</td>"
			+ "<td>" + m_fcd + "</td>"
			+ "<td>" + Stat.tronquer(m_mi, 2) + "</td>"
			+ "<td>" + Stat.tronquer(m_fimi, 2) + "</td>";
	}
	
	// Reinitialise tous nos variables statiques
	public static void reInitialiser ()
	{
		m_statFI = m_statFCC = m_statFCD = cptr = 0;
		m_statFIMI = 0;
	}
}

// ................................

class Classe
{
	// Attributs 
	private double m_li;
	private double m_ls;
	 
	// Constructeur
	public Classe (double li, double ls)
	{
		m_li = li; 
		m_ls = ls;
	}
	
	// Accesseur
	public double getLi ()
	{
		return m_li;
	}
	
	public String affichage ()
	{
		return "<td>[ " + m_li + " ~ " + m_ls + " [</td>";
	}
}
