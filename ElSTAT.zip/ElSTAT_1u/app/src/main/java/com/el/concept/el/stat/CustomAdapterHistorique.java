package com.el.concept.el.stat;

import android.widget.BaseAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.widget.TextView;

public class CustomAdapterHistorique extends BaseAdapter
{
	LayoutInflater inflater;
	String[] historique;
	
	// Constructeur
	CustomAdapterHistorique(Context context, String[] historique)
	{
		this.inflater = LayoutInflater.from(context);
		this.historique = historique;
	}
	
	public String getItem(int position)
	{
		return historique[position];
	}
	
	public int getCount()
	{
		return historique.length;
	}
	
	public long getItemId(int position)
	{
		return position;
	}
	
	static class ViewHolder
	{
		TextView mHistorique;
	}
	
	public View getView(int position, View convertView, ViewGroup parent)
	{
		ViewHolder holder = null;
		
		if(convertView == null)
		{
			convertView = inflater.inflate(R.layout.custom_layout_historique, null);
			holder = new ViewHolder();
			holder.mHistorique = (TextView)convertView.findViewById(R.id.texthist);
			convertView.setTag(holder);
		}
		
		else
		{
			holder = (ViewHolder)convertView.getTag();
		}
		
		String hist = (String)getItem(position);
		
		if(hist != null)
		{
			holder.mHistorique.setText(hist);
		}
		
		return convertView;
	}
}
