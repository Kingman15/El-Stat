package com.el.concept.el.stat;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.webkit.WebView;
import android.content.DialogInterface;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class ResultatActivity extends Activity
{
	TextView Tseriation, Tetendue, TnombreDeClasses, Tamplitude, TlimiteInferieur, Tmoyenne, Tmode, Tmediane, Tpercentile, Tdecile, Tquartile;
	WebView webView = null;
	Button perDec = null;
	Intent intent = null;
	ImageButton btnRetour;
	
	int n, k, nbChiffresApresVirgule;
	double d, a, li;
	Regroupement groupement [];

	EditText editTextPercentile;
	EditText editTextDecile;
	
	// Au cas ou l'utilisateur ecrivait un mauvais indice pour le decile ou le percentile
	int perValue=-1;
	int decValue=-1;
	
	// Utiliser lors de l'inflation de la boite de dialogue
	final Context context = this;
	
	@Override
	protected void onCreate (Bundle saveInstanceState)
	{
		super.onCreate(saveInstanceState);
		setContentView(R.layout.activity_resultat);
		
		/* 
		 * Transfert des ressources vers la classe "Stat"
		*/
		new Stat(getResources());
		
		// On recupere les vues
		btnRetour = (ImageButton)findViewById(R.id.btnRetDetRes);
		Tseriation = (TextView)findViewById(R.id.seriation);
		Tetendue = (TextView)findViewById(R.id.etendue);
        TnombreDeClasses = (TextView)findViewById(R.id.nombreDeClasses);
        Tamplitude = (TextView)findViewById(R.id.amplitude);
        TlimiteInferieur = (TextView)findViewById(R.id.limiteInferieur);
        Tmoyenne = (TextView)findViewById(R.id.moyenne);
        Tmode = (TextView)findViewById(R.id.mode);
        Tmediane = (TextView)findViewById(R.id.mediane);
        Tquartile = (TextView)findViewById(R.id.quartile);
        Tpercentile = (TextView)findViewById(R.id.percentile);
        Tdecile = (TextView)findViewById(R.id.decile);
        perDec = (Button)findViewById(R.id.perDec);
        webView = (WebView)findViewById(R.id.webView);
		
		// On recupere le tableau contenant les observations
		Intent intent = this.getIntent();
        double []modalites = intent.getDoubleArrayExtra("clef");
        
        // PLACE AU CALCUL ..........
        
        n = modalites.length;
        Stat.seriation(modalites, Tseriation); 
        d = Stat.etendue(modalites[0], modalites[n-1], Tetendue);
        k = Stat.nombreDeClasses(n, TnombreDeClasses);
        nbChiffresApresVirgule = Stat.lecture(modalites);
        a = Stat.amplitude(d, k, nbChiffresApresVirgule, Tamplitude);
        li = Stat.limiteInferieur(modalites[0], a, nbChiffresApresVirgule, TlimiteInferieur);
        
        groupement = Stat.regroupage (modalites, li, a, k);
        Stat.liorzou(groupement, webView);
        
        Stat.C_moyenne(n, Tmoyenne);
        Stat.C_mode(groupement, a, Tmode);
		Stat.C_mediane(groupement, (double)n/2, a, Tmediane);
		Stat.C_q(groupement, (double)n, a, Tquartile);
		
		perDec.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick (View v)
			{
				alertDialogShow();
			}
		});
		
		btnRetour.setOnClickListener(new View.OnClickListener()
        {
        	@Override
        	public void onClick (View v)
        	{
        		// On reinitialise les membres statiques de Regroupement 
        		Regroupement.reInitialiser();
        		finish();
        	}
        });
	}
	
	// Quand l'application n'a pas le focus 
	protected void onSaveInstanceState(Bundle saveInstanceState) 
	{
		// On reinitialise les membres statiques de Regroupement
		Regroupement.reInitialiser();
		super.onSaveInstanceState(saveInstanceState);
	}
	
	// A l'appuie sur le retour arrière
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		if(keyCode == KeyEvent.KEYCODE_BACK) 
		{
			// On reinitialise les membres statiques de Regroupement
			Regroupement.reInitialiser();
        	finish();
        	return true;
        }
		return super.onKeyDown(keyCode, event);
	}

	// pour l'affichage de la boite de dialogue
	protected void alertDialogShow() 
	{
		LayoutInflater li = LayoutInflater.from(context);
		View dialogue = li.inflate(R.layout.dialogue_per_dec, null);
				
		// Recuperation des vues dans la boite de dialogue 
		editTextPercentile = dialogue.findViewById(R.id.dialogue_percentile);
		editTextDecile = dialogue.findViewById(R.id.dialogue_decile);
				
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(R.string.question_percentile_decile);
		builder.setCancelable(true);
		builder.setView(dialogue);
				
		builder.setPositiveButton(R.string.valider, new DialogInterface.OnClickListener() 
		{
			@Override
			public void onClick(DialogInterface dialog, int which) 
			{
				if (editTextPercentile.length() > 0 && editTextPercentile.length() <= 3)
				{
					perValue = Integer.valueOf(editTextPercentile.getText().toString()).intValue();
							
					if (perValue <= 100 && perValue >= 0)
					{
						Tpercentile.setVisibility(View.VISIBLE);
						Stat.C_percentile(groupement, n, a, perValue, Tpercentile);
					}
							
				}
						
				if (editTextDecile.length() > 0 && editTextDecile.length() <= 3)
				{
					decValue = Integer.valueOf(editTextDecile.getText().toString()).intValue();
							
					if (decValue <= 10 && decValue >= 0)
					{
						Tdecile.setVisibility(View.VISIBLE);
						Stat.C_decile(groupement, n, a, decValue, Tdecile);
					}
				}
						
				if (!(perValue <= 100 && perValue >= 0))
					afficherToast(getResources().getString(R.string.incPer));
						
				else if (!(decValue <= 10 && decValue >= 0))
					afficherToast(getResources().getString(R.string.incDec));
			}
					
        });
                
		AlertDialog dialog = builder.create();
		dialog.show();
	}
	
	/*
     * Methode d'affichage des Toast
    */
    public void afficherToast(String message)
	{
		Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
	}

}
