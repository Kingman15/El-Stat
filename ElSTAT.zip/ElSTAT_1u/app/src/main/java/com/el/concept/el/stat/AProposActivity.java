package com.el.concept.el.stat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Calendar;
import android.graphics.Typeface;
import android.widget.ImageButton;
import android.os.Build;
import java.lang.Character;
import java.lang.Exception;
import android.content.res.Resources;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

/*
 * Classe gerant le bouton "A propos"
 * Ici, on cree une ListView et autres 
*/
public class AProposActivity extends Activity
{
	ListView listView;
	TextView texte;
	TextView nomApp;
	ImageButton btnRet;
	Typeface face;
	
	@Override
	protected void onCreate (Bundle saveInstanceState)
	{
		super.onCreate(saveInstanceState);
		setContentView(R.layout.activity_a_propos);
		
		// Recuperation des vues 
		listView = (ListView)findViewById(R.id.listViewAPropos);
		texte = (TextView)findViewById(R.id.texte);
		nomApp = (TextView)findViewById(R.id.nomApp);
		btnRet = (ImageButton)findViewById(R.id.btnRetDet1);
		
		face = Typeface.createFromAsset(getAssets(), "font/ABeeZee-Regular.otf");
		nomApp.setTypeface(face);
		
		texte.setText("Version : " + getResources().getString(R.string.nVersion));
		
		/* 
		 * Stockage des chaines de caracteres dans un tableau de string recuperer depuis les 
		 * ressources et qui va peupler la ListView
		*/
		String [][] option = new String[][]{
			{getResources().getString(R.string.site), getResources().getString(R.string.site2)},
			{getResources().getString(R.string.comsug), getResources().getString(R.string.comsug2)},
			{getResources().getString(R.string.aime), getResources().getString(R.string.aime2)},
			{getResources().getString(R.string.plus_detail), getResources().getString(R.string.info)}};
			
		List<HashMap<String, String>> liste = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> element;
		
		for(int i = 0 ; i < option.length ; i++) 
		{
			element = new HashMap<String, String>();
			element.put("text1", option[i][0]);
			element.put("text2", option[i][1]);
			liste.add(element);
		}
		
		ListAdapter adapter = new SimpleAdapter(this,liste, 
			android.R.layout.simple_list_item_2,
			new String[] {"text1", "text2"},
			new int[] {android.R.id.text1, android.R.id.text2 });
			
		listView.setAdapter(adapter);
		
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() 
        {
			@Override
			public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) 
			{
				Intent intent;
				
				switch(position)
				{
					// Redirection vers elconcept.cd
					case 0:
						intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://elconcept.cd"));
						demarrerActivite(intent);
					break;
					
					// Envoie d'un email
					case 1:
						intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "elconcept@gmail.com", null));
						intent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.comsug));
						intent.putExtra(Intent.EXTRA_TEXT, getDetails());
						demarrerActivite(intent);
					break;
					
					// Redirection vers la page El CONCEPT
					case 2:
						intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mobile.facebook.com/El-Concept-109975610462418"));
						demarrerActivite(intent);
					break;
					
					case 3:
						intent = new Intent(AProposActivity.this, DetailActivity.class);
        				startActivity(intent);
					break;
					
				}
			}
		});
		
		btnRet.setOnClickListener(new View.OnClickListener()
        {
        	// Quand on appuie sur la touche "Ok", on revient a l'activite principale 
        	@Override
        	public void onClick (View v)
        	{
				finish();
        	}
        });
    }
 
	private void demarrerActivite (Intent intent)
	{
		try {
			startActivity(Intent.createChooser(intent, getResources().getString(R.string.selection)));
		} catch (ActivityNotFoundException e) {
			Toast.makeText(AProposActivity.this, "R.string.actAbs", Toast.LENGTH_SHORT);
		}
	}
	
	public void cliqueImage (View vue)
	{
		int heure = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		
		if(!(heure > 7 && heure < 18))
			alertDialogShow();
	}
	
	// Methode d'affichage des boites de dialogue
	void alertDialogShow() 
	{
		// get alert_dialog.xml view
		LayoutInflater li = LayoutInflater.from(AProposActivity.this);
		View promptsView = li.inflate(R.layout.dialogue_el, null);
		
		TextView txt1 = promptsView.findViewById(R.id.eltxt1);
		TextView txt2 = promptsView.findViewById(R.id.eltxt2);
		txt1.setTypeface(face);
		txt2.setTypeface(face);
	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AProposActivity.this);
		
		// set alert_dialog.xml to alertdialog builder
		alertDialogBuilder.setView(promptsView);
		
		// set dialog message
		alertDialogBuilder.setCancelable(true);
	
		// create alert dialog
		AlertDialog alertDialog = alertDialogBuilder.create();
		// show it
		alertDialog.show();
	}
	
	
	private String getDetails()
	{
		String details = new String("MODEL = ");
		
		/* Le modele du telephone */
		String manufacturer = Build.MANUFACTURER;
		String model = Build.MODEL;
		if(model.toLowerCase().startsWith(manufacturer.toLowerCase()))
		{
			details += capitalize(model);
		}
		else
		{
			details += capitalize(manufacturer) + " " + model;
		}
		
		/* La version android du telephone */
		try {
			details += "\n" + "OS = " + String.valueOf(Build.VERSION.RELEASE) + "\n";
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		/* La version name et la version code de l'application */
		details += "VERSION = ";
		try {
			PackageInfo pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
			details += pInfo.versionName + " (" + pInfo.versionCode + ")";
		} catch(PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		
		/* La resolution de l'ecran */
		details += "\nSCREEN = " + Resources.getSystem().getDisplayMetrics().widthPixels
				+ "X" + Resources.getSystem().getDisplayMetrics().heightPixels;
		
		details += "\n_______________\n\n";
		return details;
	}
	
	private String capitalize(String s)
	{
		if(s == null || s.length() == 0)
			return "";
		
		char first = s.charAt(0);
		if(Character.isUpperCase(first))
		{
			return s;
		}
		else
		{
			return Character.toUpperCase(first) + s.substring(1);
		}
	}
	
}
