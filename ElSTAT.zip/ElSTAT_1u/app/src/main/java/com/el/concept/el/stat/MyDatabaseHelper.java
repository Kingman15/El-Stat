package com.el.concept.el.stat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class MyDatabaseHelper extends SQLiteOpenHelper
{
	private static final String TABLE_HISTORIQUE = "table_historique";
	private static final int BD_VERSION = 1;
	private static final String COLONNE_ID = "id";
	private static final String COLONNE_CONTENU = "contenu";
	private static final String REQUETE_CREATION_BD = "create table "
		 + TABLE_HISTORIQUE + " (" 
		 + COLONNE_ID + " integer primary key autoincrement, " 
		 + COLONNE_CONTENU + " text not null);";
	public static final String REQUETE_DROP = "DROP TABLE IF EXISTS " + TABLE_HISTORIQUE + ";";
		 
	public MyDatabaseHelper(Context context) 
	{
		super(context, TABLE_HISTORIQUE, null, BD_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) 
	{
		// Creation de la base
		db.execSQL(REQUETE_CREATION_BD);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) 
	{
		db.execSQL(REQUETE_DROP);
		onCreate(db);
	}
	
	// Inserer une ligne dans la BD 
	public void inserer (String distribution)
	{
		// On recupere une instance de la BD en mode ecriture
		SQLiteDatabase db = this.getWritableDatabase();
		
		ContentValues value = new ContentValues();
		value.put(COLONNE_CONTENU, distribution);
		
		db.insert(TABLE_HISTORIQUE, null, value);
	}
	
	// Renvoie toute l'historique 
	public List<String> getAllDistribution ()
	{
		// Une List vide
		List<String> distributions = new ArrayList<String>(0);
		// On selectionne tous
        String selectQuery = "SELECT  * FROM " + TABLE_HISTORIQUE + " ORDER BY " + COLONNE_ID + " DESC;";
 
        SQLiteDatabase db = this.getWritableDatabase();
        // On effectue la requete 
        Cursor c = db.rawQuery(selectQuery, null);
        
        // Si la requête ne renvoie pas de résultat.
		if (c.getCount() == 0)
			// On renvoie une List vide
			return distributions;
			
		String str;
		c.moveToFirst();
		
		// On stocke toute l'historique dans une List 
		do {
			str = c.getString(1);
			distributions.add(str);
		} while (c.moveToNext());
		
		// Ferme le curseur pour libérer les ressources.
		c.close();
		
		return distributions;
	}
	
	// Pour supprimer une ligne
	public void supprimer (String str)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TABLE_HISTORIQUE, COLONNE_CONTENU + " LIKE ? ", new String[]{str});
	}
	
	// Pour vider ...
	public void deleteAllHistorique ()
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL("DELETE FROM " + TABLE_HISTORIQUE);
	}
}
