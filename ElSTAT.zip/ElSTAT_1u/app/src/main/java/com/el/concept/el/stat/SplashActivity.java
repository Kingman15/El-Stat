package com.el.concept.el.stat;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;

public class SplashActivity extends Activity {
	@Override
    protected void onCreate(Bundle savedInstanceState) 
    {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_splash);
    	
    	/*try {
    		Thread.sleep(3000);
    	} catch(InterruptedException e) {}
    	*/
    	Intent intent = new Intent(SplashActivity.this, MainActivity.class);
    	startActivity(intent);
    	finish();
	}
}
