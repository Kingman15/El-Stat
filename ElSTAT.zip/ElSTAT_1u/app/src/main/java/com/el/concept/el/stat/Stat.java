package com.el.concept.el.stat;

import android.content.res.Resources;
import android.webkit.WebView;
import android.widget.TextView;
import java.lang.Exception;
import java.util.ArrayList;

public class Stat 
{
	private static Resources resources;
	
	/* 
	* Comme pour acceder aux ressources, il faut etre dans une activite.
	* Et comme la classe "Stat" n'herite pas de Activity, on cree notre constructeur 
	* qui recoit les ressources depuis le "ResultatActivity"
	*/
	public Stat(Resources pResources)
	{
		resources = pResources;
	}

	/*
	 * Methode aligner ()
	 * Dans cette methode, nous rangeons "la distribution dans un tableau".
	 * Cette methode fait aussi certaines verifications
	*/
	public static double []aligner (String donnees)
	{ 
		ArrayList<String> tableau = new ArrayList<String> ();
		ArrayList<Double> tab = new ArrayList<Double> ();
		int position;
		String tampon;
		double tmp;
		
		/*
		 * Dans cette boucle, on divise notre distribution
		 * En effet, comme les observations de la distribution sont separes
		 * par des espaces. Et bien, on transforme cette chaine en tableau 
		 * en se servant des espaces 
		*/
		while (donnees.length() > 0) // Tant que la longueur de la chiane est superieur a 0
		{
			// Position de l'espece 
			position = donnees.indexOf(" ");
			
			// Si l'espace est trouve ...
			if (position != -1)
			{
				// On tronque ...
				// du debut jusqu'a l'espace 
				tampon = donnees.substring(0, position);
				// On ajoute cette partie a notre tableau des Strings 
				tableau.add(tampon);
				// Comme on a recupere la premiere partie jusqu'a l'espace
				// Et bien, on l'enleve ...
				donnees = donnees.substring(position + 1);
			}
			
			// Si l'espace n'est pas trouve ...
			else
			{
				// On ajoute la partie au tableau
				tableau.add(donnees);
				// On vide la chaine pour que la boucle s'arrete 
				donnees="";
			}
		}
		
		// Si moins de deux observations
		if (tableau.size() < 2)
		{
			double vide [] = new double[]{-33333333, -33333333};
			return vide;
		}
		
		/*
		 * On essaie de convertir notre ArrayList des String 
		 * en ArrayList des Doubles ...
		*/ 
		for (int i=0; i<tableau.size(); i++)
		{
			/*
			 * Il peut arriver que l'utilisateur ecrit bcp espaces
			 * Ci-haut, on utilisait les espaces pour transformer en ArrayList
			 * Donc, si par exemple, le premier caractere est un espace et qu'on recherche l'espace, ...
			 * Au bout du compte, l'element sera vide !!! ... Donc on verifie si la longueur est superieur a 0
			 * Esparant que j'ai quand meme explique .............
			*/
			if (tableau.get(i).length() == 0)
				// Si cet element ne contient pas de caractere
				// On passe a l'iteration suivante
				continue;
			
			// ...			
			try 
			{
				tampon = tableau.get(i);
				 				
				/*
				 * En Java, des qu'une personne ecrit un nombre avec += 8 chiffres
				 * eh bien, ce nombre sera ecrit en notation scientifique,
				 * donc, bon, nous l'interdisons ...
				*/
				if (tampon.length() > 7)
				{
					double vide[] = new double [] {-22222222, -22222222};
					return vide;
				}
				
				/*
				 * Des notations telle que 6. ou .6 ou -.6 est accepte par Java.
				 * Mais pour nous, c'est interdit
				*/
				if ((tampon.charAt(0) == '.') || (tampon.charAt(0) == '-' && tampon.charAt(1) == '.') || tampon.charAt(tampon.length() - 1) == '.')
				{
					// distribution incorrecte 
					double vide[] = new double [] {-11111111, -11111111};
					return vide;
				}
				
				// On convertit en double
				tmp = Double.valueOf(tableau.get(i)).doubleValue();
				// On ajoute dans l'ArrayList
				tab.add(tmp);
				
			}
			
			// Si l'observation n'est pas un bon nombre ...
			catch (Exception e)
			{
				// distribution incorrecte
				double vide[] = new double [] {-11111111, -11111111};
				return vide;
			}
		}
		
		// Pour une utilisation aisee, on transforme en tableau
		double modalites[] = new double[tab.size()];
		int i=0;
		for(double d : tab)
		{
			modalites[i] = d;
			i++;
		}
		return modalites;
	} 
	
	/*
		- Fonction seriation ()
		- Dans cette fonction, on fait la seriation de notre tableau des modalites 
	*/
	public static void seriation (double tab[], TextView Tseriation)
	{
		int i, j;
		double tampon;
		
		String avantSeriation = new String("");
	    for (i=0; i<tab.length; i++)
	    {
	    	avantSeriation += tab[i] + "";
	    	if (i < (tab.length)-1)
				avantSeriation += "  ○  ";
	    }
	    
		// On boucle sur notre tableau 
		// Methode de tri par insertion. Du petit au plus grand.
		for (j=1; j<tab.length; j++)
		{
			// Puis ...
			for (i=0; i<(tab.length)-1; i++)
			{
				// Si celui qui precede est superieur a celui qui suit,
				// on le permute ...
				if (tab[i] > tab[i+1])
				{
					tampon = tab[i];
					tab[i] = tab[i+1];
					tab[i+1] = tampon;
				}
			}
		}
		
		String apresSeriation = new String("");
		for(i=0; i<tab.length; i++)
		{
			apresSeriation += tab[i] + "";
			if (i < (tab.length)-1)
				apresSeriation += "  ○  ";
		}
			
		Tseriation.setText(resources.getString(R.string.str_seriation_un, avantSeriation, apresSeriation, tab.length));
	}
	
	/*
		- Methode etendue ()
		- Calcule l'etendue de la serie donne par d=Xmax-Xmin 
	*/
	public static double etendue (double limiteInferieur, double limiteSuperieur, TextView tv_etendue)
	{
		double d = tronquer((limiteSuperieur - limiteInferieur), 2);
		tv_etendue.setText(resources.getString(R.string.str_etendue) + " " + limiteSuperieur + " - " + limiteInferieur + " = " + d);
		return d;
	}
	
	// Cette methode a pour but de tronquer un nombre ...
	public static double tronquer (double nbre, int Chiffres)
	{
		nbre = (double)((int)(nbre*Math.pow(10, Chiffres)))/Math.pow(10, Chiffres);
		return nbre;
	}
	
	/*
		- Methode nombreDeClasses ()
		- Elle nous renvoie le nombre des classes
	*/
	public static int nombreDeClasses (int n, TextView tv_nombreDeClasses)
	{
		// On stocke le resultat dans une variable tampon car il sera toujours decimale
		double tampon = 1+10*Math.log10(n)/3;
		tampon = tronquer(tampon, 2);
	
		// On arrondit par defaut ou par exces selon le cas, ...
		int k = (int)(tampon + 0.5);
		
		// ...
		double t1 = tronquer(Math.log10(n), 5),
			   t2 = tronquer(10*t1, 5),
			   t3 = tronquer(t2/3, 5),
			   t4 = tronquer(t3 + 1, 5);
	
		tv_nombreDeClasses.setText(resources.getString(R.string.nbreClasse) + " : k = 1+(10*log(n))/3" 
			+ " = 1+(10*" + t1 + ")/3"
			+ " = 1+(" + t2 +")/3"
			+ " = 1+" + t3 + " = " + t4 + " = " + k);
	
		return k;
	}
	
	/*
	* Methode lecture ()
	* Elle verifie si c'est un nombre decimal et renvoie le nombre des Chiffres apres virgule
	*/
	public static int lecture (double []modalites)
	{
		int i, nbChiffresApresVirgule=0;
		String []tableau = new String[modalites.length];
		String longObs;
		
		// On convertit notre tableau des modalites en tableau des String 
		for (i=0; i<modalites.length; i++)
		{
			tableau[i] = modalites[i] + "";
		}
		
		// On cherche l'observation ayant le plus de chiffres apres la virgule
		longObs = tableau[0];
		for (i=0; i<tableau.length; i++)
		{
			/*
			 * Si la longueur de la partie decimale du long observation est petit par rapport a celle de la valeur de tableau[i],
			 * tableau[i] devient la plus longue observation, donc celle ayant plus de chiffre apres la virgule ...
			*/
			if (longObs.substring(longObs.indexOf(".")+1).length() < tableau[i].substring(tableau[i].indexOf(".")+1).length())
				longObs = tableau[i];
			
			/*
			 * Sinon si la longueur de la partie decimale de la plus longue observation est egale a celle de tableau[i],
			 * et que le dernier chiffre de plus longue observation valait 0 et que celui de tableau[i] etait differend de 0,
			 * alors tableau[i] devient la plus longue observation. C'est pour remedier a : 14.0 et 14.1 ...
			*/	
			else if (longObs.substring(longObs.indexOf(".")+1).length() == tableau[i].substring(tableau[i].indexOf(".")+1).length() && longObs.charAt(longObs.length() - 1) == '0' && tableau[i].charAt(tableau[i].length() - 1) != '0')
				longObs = tableau[i];
		}
		
		/*
		 * On cherche si c'est une distribution decimale.
		 * Si oui, on renvoie le nombre des chiffres apres la
		 * virgule
		*/
		i = longObs.indexOf('.');
		// Si la distribution est decimale ...
		if(longObs.charAt(longObs.length()-1) != '0')
		{
			nbChiffresApresVirgule = longObs.substring(longObs.indexOf(".")+1).length();
		}
	
		return nbChiffresApresVirgule;
	}
	
	// Cette methode nous calcule l'amplitude d'une serie statistique 
	public static double amplitude (double d, int k, int nbChiffresApresVirgule, TextView amplitude)
	{
		String str;
		double a = d/(k-1); // On calcule l'amplitude 
	
		str = resources.getString(R.string.amplitude) + " : a = d/(k-1) = " + d + "/(" + k + "-1) = " + d + "/" + (k-1);
		
		// On garde deux chiffres apres la virgule
		a = tronquer(a, nbChiffresApresVirgule);
		
		str += " = " + a;
		
		/*
		 * Bizarrement, Java est un imbecile ...
		 * On retronque pour eviter un bug
		 * Ex.: 0.1 + 0.2 → Java ne sait pas calculer
		*/
		double t = tronquer(a, nbChiffresApresVirgule);
		if (t != a)
		{
			a = t;
			str += " = " + a;
		}
	
		// Si un entier, on ajoute un 1 facilement, ...
		if (nbChiffresApresVirgule == 0)
			a++;
	
		// Un decimal, on cherche un nombre decimal pour additionner...	
		else
		{
			// Comme c'est decimal, on doit arriver a ajouter 1 au dernier chiffre !
			int i=1;
			double tampon=0.1;
			
			while (i++ < nbChiffresApresVirgule)
				tampon /= 10;
				
			a = tronquer(a += tampon, nbChiffresApresVirgule);
		}
	
		str += " = " + a;
		amplitude.setText(str);
		return a;
	}
	
	// Ici, on calcule la limite inferieur 
	public static double limiteInferieur (double xmin, double a, int nbChiffresApresVirgule, TextView TlimiteInferieur)
	{
		double li = xmin-a/2;
		
		// On essaie de tronquer apres deux chiffres la virgule
		li = tronquer(li, 2);
		
		String str = resources.getString(R.string.li) + " : li = Xmin-a/2 = " + xmin + "-" + a + "/2 = " + xmin + " - " + a/2 + " = " + li;
	
		// Si c'est une distribution decimale
		if (nbChiffresApresVirgule > 0)
		{
			double tampon = tronquer(li, nbChiffresApresVirgule);
			
			if(tampon != li)
			{
				li = tampon;
				str += " = " + li;
			}
		}
	
		// Au cas contraire, on arrondit
		else
		{
			String chaine = new String();
			// Conversion en String
			chaine = String.valueOf(li);
			
			// Recuperation de la position du point 
			int i = chaine.indexOf('.');
			// On recupere le code ascii du premier caractere apres la virgule 
			int nbre = Integer.valueOf(chaine.charAt(i+1)).intValue();
			
			// Le code ascii de 5 vaut 53
			// Donc si le chiffre apres la virgule est superieur ou egal a cinq
			if (nbre >= 53)
			{
				// On arrondit  
				li = (int)(li+0.5);
				
				str += " = " + li;
			}
			
			// Si le chiffre apres la virgule est inferieur a cinq
			else
			{
				// on coupe la partie decimale 
				double tampon = (int)li;
				
				// Si apres voir enlever la partie decimale, le nombre change
				// ...
				if (tampon != li)
				{
					str += " = " + tampon;
				}
			}
		}
		
		TlimiteInferieur.setText(str);
		return li;
	}
	
	/*
	 * On cree de maniere programmatique un String qui va permettre
	 * de creer un tableau versus HTML
	*/
	public static void liorzou (Regroupement []tab, WebView webView)
	{
		String str = new String();
		
		str = "<html><head><meta charset=\"utf-8\"/><style> body { user-select: none; -moz-user-select: none;"
			+ " -khtml-user-select: none; -webkit-user-select: none;} table {border-collapse: collapse; width: 100%; font-size: 14px; /*table-layout: fixed;*/"
			+ " vertical-align: center;} td, th {border: 1px double black; text-align: center;} th {background-color: #E1E1E1 }; </style></head><body>"
			+ "<table><caption><b>" + resources.getString(R.string.titreReg) + "</b></caption><thead><tr>";
		
		// On cree l'en-tete du tableau
		str +=   "<th>Classes</th>"
			+	"<th>fi</th>"
			+	"<th>fi/N</th>"
			+	"<th>fi/N*100</th>"
			+	"<th>FCC</th>"
			+	"<th>FCD</th>"
			+	"<th>mi</th>"
			+	"<th>fimi</th>"
			+	"</tr></thead>";
		
		// On ajoute le total et s'attaque au corps 
		str += Regroupement.total() + "<tbody>";
		
		// On ajoute chaque ligne
		for (int i=0; i<tab.length; i++)
			str += "<tr>" + tab[i].affichage() + "</tr>";
		
		str += "</tbody></body></html>";
		
		// On affiche ...
		webView.loadData(str, "text/html", "UTF-8");
	}
	
	/*
		Cette methode regroupe en classe notre serie !
	*/
	public static Regroupement [] regroupage (double modalites [], double li, double amplitude, int k)
	{
		int i, j, t=0;
		double tab[] = new double [k*2]; // Tableau qui contiendra les limites des classes 
		int fi[] =  new int [k]; // Tableau qui contiendra les frequences absolues 
		
		tab[0] = li;
		int n = modalites.length;
		
		// Creation d'un tableau comportant les limites inferieures et superieures
		for(i=1; i<k*2; i+=2)
		{
			tab[i] = tronquer((tab[i-1]+amplitude), 2);
			// Si c'est pas la deniere classe
			if(k*2-i >= 2)
				tab[i+1] = tab[i];
		}
		
		// Creation d'un tableau comportant les frequences absolues
		for(i=0, j=1; i<k; i++, j+=2)
		{
			fi[i] = 0;
			while(t<modalites.length && modalites[t] < tab[j])
			{
				++fi[i];
				++t;
			}
		}
		
		// Creation de nos objets
		Regroupement tableau [] = new Regroupement[k];
		i=0;
		for(int a=0, b=1; i<k; i++, a+=2, b+=2)
		{
			tableau[i] = new Regroupement(tab[a], tab[b], fi[i], n);
		}
		
		return tableau;
	}

		// Calcul de la moyenne
	public static double C_moyenne (int n, TextView Tmoyenne)
	{
		double moyenne = Regroupement.totalFimi()/n;
		moyenne = tronquer(moyenne, 2);
		Tmoyenne.setText(resources.getString(R.string.formuleMoyenne) + " " + Regroupement.totalFimi() + "/" + n + " = " + moyenne);
		return moyenne;
	}
		
		// Fonction de recherche de la classe modale
	public static int [] recherche (Regroupement []tab)
	{
		int position=0; // Position de la classe correspondante 
		int plusMode=0;
	
		// Pour le mode, on recherche la classe ayant la plus grande frequence absolue et on stocke son indice 
		// par rapport a notre tableau des classes 
		Regroupement tampon = tab[0];
		for (int i=0; i<tab.length; i++)
		{
			if (tab[i].getFi() > tampon.getFi())
			{
				tampon = tab[i];
				position = i;
			}
		}
		
		int mode = tab[position].getFi();
		for(int i=position+1; i<tab.length; i++)
		{
			if (mode == tab[i].getFi())
			{
				plusMode = 1;
				break;
			}
		}
		
		int positions[] = new int[2];
		positions[0] = position;
		positions[1] = plusMode;
		return positions;
	}
	
		// Fonction de recherche des classes
	public static int recherche (Regroupement []tab, double nbre)
	{
		/*
			De maniere generique, on recherche la bonne classe par rapport au FCC.
			Si le nombre passe en parametre n'y est pas, on prend le fcc superieur mais rapproche
				et l'indice de cette classe est renvoye puis utilise !
		*/
		int position=0;
		for (int i=0; i<tab.length; i++)
		{
			if (tab[i].getFcc() >= nbre)
			{
				position = i;
				break;
			}
		}
		
		return position;
	}
	
		// Calcul du mode
	public static void C_mode (Regroupement []tab, double a, TextView Tmode)
	{
		int positions[] = recherche(tab); // On stocke dans i l'indice de la classe modale
		int i = positions[0];
		String rang;
		
		if (i == 0)
			rang = resources.getString(R.string.ere);
		else if (i == 1)
			rang = resources.getString(R.string.nd);
		else
			rang = resources.getString(R.string.ieme);
			
		String str = new String("");
		
		// Si sa distribution contient plus d'une classe modale ...
		if(positions[1] == 1)
			// On le lui dit
			str += new String(resources.getString(R.string.avertissement));
		
		// Sinon, ...
		else
		{
			str += new String(resources.getString(R.string.mode, i+1, rang));
	
			str += "● Mode = li+a*(Var1/(Var1+Var3)) = ";
			
			// Frequences absolues precendent et suivant
			int fip = (i == 0) ? 0 : tab[i-1].getFi(); // Si la classe modale est sur la premiere ligne, on met la frequence absolue precedente a 0
			int fis = (i == tab.length-1) ? 0 : tab[i+1].getFi(); // Si la classe modale est sur la derniere ligne, on met la frequence absolue suivante a 0
		
			// Les variations	
			int var1 = tab[i].getFi() - fip;
			int var2 = tab[i].getFi() - fis;
		
			double li = tab[i].getLi();
			double mode = li+a*var1/(var1+var2);
			mode = tronquer(mode, 2);
			
			str += li + "+" + a + "*(" + var1 + "/(" + var1 + "+" + var2 + ")) = " + mode;
		}
		
		Tmode.setText(str);
	}
	
		// Calcul de la mediane 
	public static void C_mediane (Regroupement []tab, double n, double a, TextView Tmediane)
	{
		// a ne pas confondre n de la taille avec le n d'ici.
		// car ici, le n, c'est n proprement dit diviser par 2
		int i = recherche (tab, n); // On stocke dans i l'indice de la classe mediane 
		
		String rang;
		
		if (i == 0)
			rang = resources.getString(R.string.ere);
		else if (i == 1)
			rang = resources.getString(R.string.nd);
		else
			rang = resources.getString(R.string.ieme);
			
		String str = new String(resources.getString(R.string.txtMediane, i+1, rang));
	
		int fccp = (i == 0) ? 0 : tab[i-1].getFcc(); // Si la classe mediane est sur la premiere ligne, on met la frequence absolue precedente a 0
		double mediane = tab[i].getLi()+a*((n-fccp)/tab[i].getFi());
		mediane = tronquer(mediane, 2);
		str += resources.getString(R.string.mediane) + " = li+a[(n/2 - fccp)/n(med)] = " + tab[i].getLi() + "+" + a +  "*(" + n +"-" + fccp + ")/" + tab[i].getFi() + " = " +  mediane;
	
		Tmediane.setText(str);
	}

	/*
		- Fonction C_q ()
		- Elle calcule les trois quartiles 
	*/
	public static void C_q (Regroupement []tab, double n, double a, TextView Tquartile)
	{
		double quartile [] = new double[3];
		double indice [] = {n/4, n/2, 3*n/4}; // Nous stockons tous les formules de "i" dans un tableau 
		String formule [] = new String[]{"n/4", "n/2", "3*n/4", n+"/4", n+"/2", "3*"+n+"/4"};
		String str = new String(resources.getString(R.string.txtQuartile));
		int position [] = new int[3];
		int fccp;
	
		for (int i=0; i<3; i++)
		{
			position[i] = recherche (tab, indice[i]); // On stocke tous les indices des classes correspondantes dans un tableau des "positions"
			fccp = (position[i] == 0) ? 0 : tab[position[i]-1].getFcc(); // Si la classe correspondante est sur la premiere ligne, on met la frequence absolue precedente a 0
			quartile[i] = tab[position[i]].getLi()+a*((indice[i]-fccp)/tab[position[i]].getFi()); // On calcule les trois quartiles 
			quartile[i] = tronquer(quartile[i], 2);
			
			str += "○ Indice Q" + (i+1) + " = " + formule[i] + " = " + formule[i+3] + " = " + indice[i] + "\n";
			str += "→ Q" + (i+1) + " = li+a*[(i-FCCp)/nq" + (i+1) + "] = " + tab[position[i]].getLi() + "+" 
				+ a + "*" + "[(" + indice[i] + "-" + fccp +")/" + tab[position[i]].getFi() + "] = " + quartile[i];
			
			if (i < 2)
				str += "\n\n"; 
		}
		
		Tquartile.setText(str);
	}

		// Calcul du percentile
	public static void C_percentile(Regroupement []tab, int n, double a, int p, TextView tPercentile)
	{
		double indice = tronquer(((p/100.)*n), 2);
		int i = recherche (tab, indice);
		int fccp = (i == 0) ? 0 : tab[i-1].getFcc();
		double percentile = tab[i].getLi()+a*((indice-fccp)/tab[i].getFi());
		
		String rang;
		if (p == 1)
			rang = resources.getString(R.string.er);
		else if (p == 2)
			rang = resources.getString(R.string.nd);
		else
			rang = resources.getString(R.string.ieme);
			
		String str = "● " + resources.getString(R.string.cPer, p, rang);
		str += " = (p/100)*n = (" + p + "/100)*" + n + " = " + indice;
		str += "\n○ P" + p + " = li+a*[(i-FCCp)/np" + p + "] = " 
			+ tab[i].getLi() + "+" + a + "*" + "[(" + indice + "-" 
			+ fccp +")/" + tab[i].getFi() + "] = " + tronquer(percentile, 2);;
		
			
		str += "\n\n→ " + resources.getString(R.string.str_percentile, p, rang) + " " + tronquer(percentile, 2);
			
		tPercentile.setText(str);
	}

		// Calcul du decile 
	public static void C_decile(Regroupement []tab, int n, double a, int d, TextView tDecile)
	{
		double indice = tronquer(((n/10.)*d), 2);
		int i = recherche (tab, indice);
		int fccp = (i == 0) ? 0 : tab[i-1].getFcc();
		double decile = tab[i].getLi()+a*((indice-fccp)/tab[i].getFi());
		
		String rang;	
		if (d == 1)
			rang = resources.getString(R.string.er);
		else if (d == 2)
			rang = resources.getString(R.string.nd);
		else
			rang = resources.getString(R.string.ieme);
			
		String str = "● " + resources.getString(R.string.cDec, d, rang);
		str += " = (n/10)*d = (" + n + "/10)*" + d + " = " + indice;
		str += "\n○ D" + d + " = li+a*[(i-FCCp)/nd" + d + "] = " + tab[i].getLi() 
			+ "+" + a + "*" + "[(" + indice + "-" + fccp +")/" + tab[i].getFi() 
			+ "] = " + tronquer(decile, 2);
			
		str += "\n\n→ " + resources.getString(R.string.str_decile, d, rang) + " " + tronquer(decile, 2);
		
		tDecile.setText(str);
	}
}




