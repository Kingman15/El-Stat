package com.el.concept.el.stat;

import android.app.Activity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ImageButton;
import java.util.ArrayList;
import java.util.List;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;
import android.widget.AdapterView.OnItemClickListener;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.widget.Toast;
import android.content.DialogInterface;
import android.view.Gravity;

public class HistoriqueActivity extends Activity
{
	ListView listView;
	ImageButton btnRet, btnSupp;
	private List<String> distributions;
	private CustomAdapterHistorique customAdapter;
    TextView mEmpty=null;
    
    ClipboardManager myClipboard;
	ClipData myClip;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historique);
        
        listView = (ListView)findViewById(R.id.listView);
        btnRet = (ImageButton)findViewById(R.id.btnRet);
        btnSupp = (ImageButton)findViewById(R.id.btnSupp);
        
        myClipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        
        MyDatabaseHelper db = new MyDatabaseHelper(this);
        distributions = new ArrayList<String>();
        
        // On recupere l'historique dans la BD
        List<String> list = db.getAllDistribution();
        
        // Si l'historique existe ...
        if (list.size() > 0)
        {
	        distributions.addAll(list);
	        
	        // On transforme en String 
	        String[] historiques = new String[distributions.size()];
	        int i=0;
	        for(String str : distributions)
	        {
	        	historiques[i] = str;
	        	i++;
	        }
	        
			customAdapter = new CustomAdapterHistorique(this, historiques);
			listView.setAdapter(customAdapter);
		}
		
		// Si l'historique est vide
		else
			vide();
			
		// On ajoute un Listener sur les items de la liste
        listView.setOnItemClickListener(new OnItemClickListener() 
        {
        	// Que se passe-il en cas de cas de clic sur un element de la liste ?
			public void onItemClick(AdapterView<?> adapter, View view, int position, long id) 
			{
				String str = customAdapter.getItem(position);
				
				// Cet item revient en premier dans l'historique 
				MyDatabaseHelper db = new MyDatabaseHelper(HistoriqueActivity.this);
				// on supprime 	
		    	db.supprimer(str);
		        // on reinsere
		        db.inserer(str);
				
				str = str.replaceAll("○", " ");
				str = str.replaceAll(" ", " ");
				
				double modalites[] = Stat.aligner(str);
				Intent intent = new Intent(HistoriqueActivity.this, ResultatActivity.class);
	        	intent.putExtra("clef", modalites);
	        	startActivity(intent);
			}
		});
		
		listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() 
		{
			@Override
			public boolean onItemLongClick(AdapterView<?> adapterView,View view,int position,long id) 
			{
				String str = customAdapter.getItem(position);
				str = str.replaceAll("○", " ");
				
				myClip = ClipData.newPlainText("text", str);
				myClipboard.setPrimaryClip(myClip);
				
				Toast.makeText(HistoriqueActivity.this, R.string.texteCopie, Toast.LENGTH_SHORT).show();
				return true;
			}
		});
		
		btnRet.setOnClickListener(new View.OnClickListener ()
		{
			@Override
			public void onClick(View v)
			{
				finish();
			}
		});
		
		// A l'appui sur l'ImageButton "Supprimer"
		btnSupp.setOnClickListener(new View.OnClickListener ()
		{
			@Override
			public void onClick(View v)
			{
				alertDialogShow();
			}
		});
		
		// Quand on appuie de maniere prolongee sur le bouton supprimer,
		// et bien, on affiche un toast ...
		btnSupp.setOnLongClickListener(new View.OnLongClickListener()
		{
			@Override
			public boolean onLongClick(View v)
			{
				Toast toast = Toast.makeText(HistoriqueActivity.this, R.string.vider, Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.TOP|Gravity.RIGHT, 0, 100);
				toast.show();
				return true;
			}
		});
		
	}

	// Pour vider la BD
	private void supprimer ()
	{
		MyDatabaseHelper db = new MyDatabaseHelper(this);
		db.deleteAllHistorique();
		// On vide la "List"
		distributions.clear();
		// On met a jour notre ArrayAdapter
		customAdapter.notifyDataSetChanged();
	}
	
	// Dans le cas ou l'historique est vide
	private void vide ()
	{
		// On recupere un TextView invisible 
		mEmpty = (TextView)findViewById(R.id.empty);
		// On cache la ListView
		listView.setVisibility(View.GONE);
		// On fait disparaitre le bouton "Effacer"
		btnSupp.setVisibility(View.INVISIBLE);
		// On rend le TextView visible
		mEmpty.setVisibility(View.VISIBLE);
		// On affiche un message
		mEmpty.setText(getResources().getString(R.string.vide));
	}
	
	protected void alertDialogShow() 
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.effacer);
		builder.setMessage(R.string.qEffacer);
		builder.setCancelable(false);
				
		builder.setPositiveButton(R.string.valider, new DialogInterface.OnClickListener() 
		{
			@Override
			public void onClick(DialogInterface dialog, int which) 
			{
				supprimer();
				vide();
			}	
		});
		
		builder.setNegativeButton(R.string.annuler, new DialogInterface.OnClickListener() 
		{
			@Override
			public void onClick(DialogInterface dialog, int which) 
			{
			}	
		});
                
		AlertDialog dialog = builder.create();
		dialog.show();
	}
	
}
