package com.el.concept.el.stat;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.content.DialogInterface;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import java.util.Calendar;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends Activity 
{
	TextView appName;
	EditText mEntrer, nbCarac;
	Button mValider, mAPropos, mEcriture, mHist;
	ImageButton mEffacer;
	
	// Utiliser lors de l'inflation de la boite de dialogue
	final Context context = this;
	
	// Utiliser pour l'automatisation des espaces 
	int pas=0, saute=0;
	boolean ecriture=false;
	
	// Pour la gestion du bouton de retour a la sortie
	int secondeAvant = 0, minuteAvant = 0, heureAvant = 0;
	int secondeApres = 0, minuteApres = 0, heureApres = 0;
	boolean countdown = false;
	Toast qToast = null;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // On recupere les vues 
        appName = (TextView)findViewById(R.id.textAppName);
        mEntrer = (EditText)findViewById(R.id.etEcrire);
        mValider = (Button)findViewById(R.id.btnValider);
        mEcriture = (Button)findViewById(R.id.btnEcriture);
        mHist = (Button)findViewById(R.id.btnHist);
        mAPropos = (Button)findViewById(R.id.btnAPropos);
        mEffacer = (ImageButton)findViewById(R.id.btnEffacer);
        
        // "Appuyer une autre fois pour quitter"
        qToast = Toast.makeText(MainActivity.this, R.string.quitter, Toast.LENGTH_LONG);
        
        // Ajout d'un ecouteur de clique sur l'EditText principal
        mEntrer.setOnKeyListener(new View.OnKeyListener()
        {
        	@Override
        	public boolean onKey(View v, int keyCode, KeyEvent event) 
        	{
        		// A l'appuie de la touche entree, on passe au calcul
	        	if(keyCode == 66)
	        	{
	        		 valider();
	        		 return true;
	        	}
	        	
	        	// A l'appui de la touche Supprimer ...
	        	if (keyCode == KeyEvent.KEYCODE_DEL && ecriture == true)
	        	{
	        		ecriture = false;
	        		afficherToast(getResources().getString(R.string.ecrDes));
	        	}
	        	return false;
        	}
        });
        
        /* 
         * TextWatcher de l'EditText detectant le changement.
         * Si l'EditText devient vide, le bouton "effacer" est desactive
        */
        mEntrer.addTextChangedListener(new TextWatcher()
        {
        	@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) 
			{
				// Si l'EditText n'est pas vide 
				if (mEntrer.length() > 0)
				{
					mEffacer.setVisibility(View.VISIBLE);
				}
				
				// Si elle est vide, le bouton effacer est desactive
				else
				{
					mEffacer.setVisibility(View.INVISIBLE);
				}
				
				/*
				 * TEST D'ERREUR 
				 * start : position caractere qui est entrain de changer
				 * Si la modification n'est pas faite a la fin, on desactive ...
				 * count : nombre des caracteres qui sont entrain de changer
				 * Si count > 1, donc, quand on colle quelque chose, on desactive ...
				 * A la fin, on teste si "saute < pas", ...
				 *	→ Eh oui, si ecriture est active, quand la condition d'insertion
				 *	→ est remplie, en remplissant, "count" deviendra superieur a 1, 
				 *	→ sans cela, ecriture sera desactive !!! ...	
				*/ 
				if (ecriture == true && (start != mEntrer.length() - 1 || count > 1) && saute < pas)
				{
					ecriture = false;
	        		afficherToast(getResources().getString(R.string.ecrDes));
				}
					
				// Si le mode ecriture est active ...
				if (ecriture)
				{
					saute++;
					// Si on atteind le pas specifie
					if (saute == pas)
					{
						// On ajoute un espace a l'EditText
						mEntrer.setText(mEntrer.getText().toString() + " ");
						// On remet le curseur a la fin 
						mEntrer.setSelection(mEntrer.length());
						// On remet le "saute" a zero
						saute = 0;
					}
				}
        	}
        	
        	// Avant le changement du texte 
        	@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) 
			{
			}
			
			// Apres le changement du texte 
			@Override
			public void afterTextChanged(Editable s) 
			{
			}
        });
        
        // Boutton "valider"
        mValider.setOnClickListener(new View.OnClickListener() 
        {
        	@Override
        	public void onClick (View v)
        	{
        		// Appel a la methode de calcul
        		valider();
        	}
        });
        
        // Boutton "ecriture"
        mEcriture.setOnClickListener(new View.OnClickListener()
        {
        	@Override
        	public void onClick (View v)
        	{
        		// On ouvre la boite de dialogue 
        		alertDialogShow();
        	}
        });       

        // ImageBoutton "effacer"
        mEffacer.setOnClickListener(new View.OnClickListener()
        {
        	@Override
        	public void onClick (View v)
        	{
        		// On desactive le mode "ecriture"
        		ecriture = false;
        		// On vide l'EditText
        		mEntrer.getText().clear();
        	}
        });
     
        // Bouton "Historique"
        mHist.setOnClickListener(new View.OnClickListener()
        {
        	@Override
        	public void onClick (View v)
        	{
        		// On demarre l'activite de l'historique
				Intent intent = new Intent(MainActivity.this, HistoriqueActivity.class);
        		startActivity(intent);
        	}
        });
      
        // Bouton "A propos de l'auteur"
        mAPropos.setOnClickListener(new View.OnClickListener()
        {
        	@Override
        	public void onClick (View v)
        	{
        		// On demarre l'activite de "A propos"
				Intent intent = new Intent(MainActivity.this, AProposActivity.class);
        		startActivity(intent);
        	}
        });
    }
    
    // Appelée lorsque que l’activité est suspendue
    @Override
	public void onPause()
	{
		qToast.cancel();
		countdown = false;
		super.onPause();
	}
    
    /*
     * Methode d'affichage des Toast
    */
    public void afficherToast(String message)
	{
		Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
		// On positionne le "Toast" au milieu
		toast.setGravity(Gravity.CENTER, 0, 40);
		toast.show();
	}
	
	/*
	 * A l'appui de la touche "Valider", on fait appel a cette methode
	 * Elle verifie ..., en passant par "Stat", puis passe le relais a "ResultatActivity"
	*/
	public void valider ()
	{
		// On recupere le contenu de l'EditText
		String entrer = mEntrer.getText().toString();
		
        boolean passe = false;
        		
    	/* 
    	 * On verifie que l'utilisateur a au moins ecrit un chiffre
     	* et implicitement si son EditText n'est pas vide
    	*/
    	for (int i=0; i<entrer.length(); i++)
        {
        	if (Character.isDigit(entrer.charAt(i)))
        	{
				passe = true;
				break;
			}
        }
        
        /* 
        * Si l'utilisateur n'a pas ecrit au moins un chiffre, 
        * on affiche un toast, et on vide l'EditText
        */
        if (passe == false)
        {
        	afficherToast(getResources().getString(R.string.dmd_distribution));
        	mEntrer.getText().clear();
        }
        
        // Ou sinon ...		
        else
        {
        	/* 
        	 * Tentative de convertir l'entree de l'utilisateur en tableau.
        	 * Si pas possible, la classe "Stat" nous renvoie des resultats
        	 * qui nous permet a detecter les erreurs
        	*/
        	double modalites[] = Stat.aligner(entrer);
        	
        	// Si l'utilisateur a ecrit une seule observation	
        	if (modalites.length == 2 && modalites[0] == -33333333 && modalites[1] == -33333333)
        	{
        		afficherToast(getResources().getString(R.string.plus_modalites));
        	}
        	
        	/*
        	 * Si sa distribution n'est pas correcte.
        	 * Mauvaise utilisation des caracteres alphanumeriques ...
        	*/
        	else if (modalites.length == 2 && modalites[0] == -11111111 && modalites[1] == -11111111)
        	{
        		afficherToast(getResources().getString(R.string.erreur_ecriture));
        	}
        	
        	/*
        	 * S'il a ecrit un grand nombre donc a partir de plus de 7 chiffres,
        	 * El STAT n'arrive pas a le calculer !
        	*/
        	else if (modalites.length == 2 && modalites[0] == -22222222 && modalites[1] == -22222222)
        	{
        		afficherToast(getResources().getString(R.string.impossible_calcul));
        	}
        		
        	// Si sa distribution repond aux criteres, ...	
        	else
        	{
        		/*
        		 * Si sa distribution contient plus de 5 observations, on
        		 * l'enregistre dans la base des donnees
        		*/
        		if (modalites.length >= 5)
	    		{
		    		MyDatabaseHelper db = new MyDatabaseHelper(this);
		        
		        	/*
		        	 * On convertit notre tableau de modalites en String pour 
		        	 * l'enregistrer dans la BD 
		        	*/
		        	String historique = new String("");
		        	for (int i=0; i<modalites.length; i++)
		        	{
		        		historique += modalites[i] + "";
		        		// Si c'est pas la derniere observation
		        		if (i < (modalites.length)-1)
		        			historique += " ○ ";
		        	}
		        	
		        	// Si cette distribution existe, on la supprime 	
		        	db.supprimer(historique);
		        	// On insere notre String des modalites
		        	db.inserer(historique);
	    		}
	    		
	        	Intent intent = new Intent(MainActivity.this, ResultatActivity.class);
	        	// Ajout du tableau de distribution a l'Intent
	        	intent.putExtra("clef", modalites);
	        	startActivity(intent);
        	}
        }		
	}
	
	// pour l'affichage de la boite de dialogue
	protected void alertDialogShow() 
	{
		// get alert_dialog.xml view
		LayoutInflater li = LayoutInflater.from(context);
		View dialogue = li.inflate(R.layout.dialogue_ecriture, null);
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
		
		// set alert_dialog.xml to alertdialog builder
		alertDialogBuilder.setView(dialogue);
		
		// On recupere l'EditText dans la boite de dialogue
		nbCarac = dialogue.findViewById(R.id.nb_carac);
		
		// set dialog message
		alertDialogBuilder.setCancelable(true);
		
		// A l'appui sur "Valider"
		alertDialogBuilder.setPositiveButton(R.string.valider, new DialogInterface.OnClickListener() 
		{
			@Override
			public void onClick(DialogInterface dialog, int which) 
			{
				/*
				 * On teste si l'EditText contient entre 1 et 3 caracteres
				 * C'est pour eviter lors du Cast String -> Int.
				 * Si l'utilisateur entrer une tres longue chaine, lors du cast, on aura
				 * un NumberFormatException et il y aura un plantage
				 * Je sais, il y a necessairement mieux a faire ...
				*/
				if (nbCarac.length() > 0 && nbCarac.length() <= 3)
				{
					// On convertit
					pas = Integer.valueOf(nbCarac.getText().toString()).intValue();
							
					// L'utilisateur doit entrer entre 1 et 5 
					if (pas > 0 && pas <= 5)
						ecriture = true;
								
					else
						ecriture = false;
				}
						
				if (!ecriture)
        			afficherToast(getResources().getString(R.string.correctePas));
        		else
        			afficherToast(getResources().getString(R.string.ecrAct));
        				
			}
		});
		
		alertDialogBuilder.setNegativeButton(R.string.annuler, new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int id) 
			{
				dialog.cancel();
			}
		});
		
		// create alert dialog
		AlertDialog alertDialog = alertDialogBuilder.create();
		// show it
		alertDialog.show();
	}
	
	// A l'appuie sur le retour arrière
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		if(keyCode == KeyEvent.KEYCODE_BACK) 
		{
			
				// Contient la date et l'heure au moment de sa création
				Calendar calendrier = Calendar.getInstance();
					
				if (countdown == false)
				{
					heureAvant = calendrier.get(Calendar.HOUR_OF_DAY);
					minuteAvant = calendrier.get(Calendar.MINUTE);
					secondeAvant = calendrier.get(Calendar.SECOND);
					qToast.show();
					countdown = true;
				}
				
				else
				{
					heureApres = calendrier.get(Calendar.HOUR_OF_DAY);
					minuteApres = calendrier.get(Calendar.MINUTE);
					secondeApres = calendrier.get(Calendar.SECOND);
					
					if (heureAvant == heureApres && minuteAvant == minuteApres && secondeApres-secondeAvant <= 4)
					{
						qToast.cancel();
						finish();
					}
					
					else
					{
						qToast.show();
						heureAvant = heureApres;
						minuteAvant = minuteApres;
						secondeAvant = secondeApres;
					}
			}
			return true;	
	    }
		return super.onKeyDown(keyCode, event);
	}	

}
